﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using Monopoly;
using System.Linq;
using Monopoly_tests;
using System.Reflection;

namespace Monopoly_tests
{

    #region Design Pattern Player 

    [TestClass]
    public class PlayerTests
    {

        [TestMethod]
        public void PlayerTest()
        {
            Player player1 = new Player("player");
            Assert.AreEqual("player", player1.Pseudo);
        }

        [TestMethod]
        public void MoveOnTest()
        {
            Player player1 = new Player("player");
            player1.MoveOn();
            Assert.IsTrue(player1.CurrentSquare != 1); //because start at position 1/40
        }



    }

    [TestClass]
    public class PlayerListTest
    {
        [TestMethod]
        public void AddPlayer_Test()
        {
            Player player1 = new Player("player1");
            PlayerList playerList = new PlayerList();
            playerList.AddPlayer(player1);
            Assert.IsTrue(playerList.Count != 0);

        }

        [TestMethod]
        public void GetPlayer_Test()
        {
            Player player1 = new Player("player1");
            PlayerList playerList = new PlayerList();
            playerList.AddPlayer(player1);
            Assert.AreEqual(player1, playerList.GetPlayer(0));

        }

        [TestMethod]
        public void CountPlayer_Test()
        {
            Player player1 = new Player("player1");
            PlayerList playerList = new PlayerList();
            playerList.AddPlayer(player1);
            Assert.AreEqual(1, playerList.Count);

        }

    }


    [TestClass]
    public class PlayerListItaratorTest
    {
        // test the iterator at the same time 

        //test hasNext on an empty collection(returns false)
        //test next() on an empty collection(throws exception)
        //test hasNext on a collection with one item(returns true, several times)
        //test hasNext/next on a collection with one item: hasNext returns true, next returns the item, hasNext returns false, twice
        //test remove on that collection: check size is 0 after
        //test remove again: exception
        //final test with a collection with several items, make sure the iterator goes through each item, in the correct order(if there is one)
        //remove all elements from the collection: collection is now empty


        [TestMethod]
        public void FirstTest()
        {
            Player player1 = new Player("player1");
            PlayerList playerList = new PlayerList();
            playerList.AddPlayer(player1);
            PlayerListIterator iterator = playerList.CreateIterator();
            Assert.AreEqual(player1, iterator.First());

        }

        [TestMethod]
        public void NextTest()
        {
            Player player1 = new Player("player1");
            // Player player2 = new Player("player2");
            PlayerList playerList = new PlayerList();
            playerList.AddPlayer(player1);
            // playerList.AddPlayer(player2);
            PlayerListIterator iterator = playerList.CreateIterator();
            Assert.AreEqual(null, iterator.Next());
            //Assert.AreEqual(player2, iterator.Next());
        }

        [TestMethod]
        public void NextTest2() //on an empty collection
        {
            PlayerList playerList = new PlayerList();
            PlayerListIterator iterator = playerList.CreateIterator();
            Assert.AreEqual(null, iterator.Next());
        }


        [TestMethod]
        public void IsCompletedTest()
        {
            Player player1 = new Player("player1");
            PlayerList playerList = new PlayerList();
            playerList.AddPlayer(player1);
            PlayerListIterator iterator = playerList.CreateIterator();
            Assert.AreEqual(false, iterator.IsCompleted);
        }

        [TestMethod]
        public void IsCompletedTest2()
        {
            Player player1 = new Player("player1");
            PlayerList playerList = new PlayerList();
            playerList.AddPlayer(player1);
            PlayerListIterator iterator = playerList.CreateIterator();
            iterator.Next();
            Assert.AreEqual(true, iterator.IsCompleted);
        }

        [TestMethod]
        public void IsCompletedTest3()
        {
            PlayerList playerList = new PlayerList();
            PlayerListIterator iterator = playerList.CreateIterator();
            Assert.AreEqual(true, iterator.IsCompleted);
        }

    }


    #endregion

    #region Design Pattern Board game 

    [TestClass]
    public class BoardSingletonClass
    {
        [TestMethod]
        public void BoardGamesingleton()
        {
            BoardgameSingleton boardgame1 = BoardgameSingleton.GetInstance;
            BoardgameSingleton boardgame2 = BoardgameSingleton.GetInstance;
            Assert.AreEqual(boardgame1, boardgame2);
        }


        [TestMethod]
        public void GetInstanceTest()
        {
            BoardgameSingleton boardgame = BoardgameSingleton.GetInstance;
            Assert.AreEqual(boardgame.GetType(), typeof(BoardgameSingleton));
        }


        [TestMethod]
        public void AddSquare_Test()
        {
            BoardgameSingleton boardgame = BoardgameSingleton.GetInstance;
            Assert.IsTrue(boardgame.Count != 0);

        }

        [TestMethod]
        public void GetSquare_Test()
        {
            BoardgameSingleton boardgame = BoardgameSingleton.GetInstance;
            Assert.IsTrue(boardgame.GetSquare(0) != null);

        }

        [TestMethod]
        public void GetSquare_Test2()
        {
            BoardgameSingleton boardgame = BoardgameSingleton.GetInstance;
            Assert.AreEqual(boardgame.GetSquare(0).GetSquareType(), "Starter Square");

        }

        [TestMethod]
        public void BoardCount_Test()
        {
            BoardgameSingleton boardgame = BoardgameSingleton.GetInstance;
            Assert.AreEqual(40, boardgame.Count);
        }
    }


    [TestClass]
    public class BoardGameIteratorTest
    {

        [TestMethod]
        public void BoardGameFirstTest() //Check exist 
        {
            BoardgameSingleton boardgame = BoardgameSingleton.GetInstance;
            BoardgameIterator boardgameIterator = boardgame.CreateIterator();
            Assert.IsTrue(boardgameIterator.First() != null);

        }

        [TestMethod]
        public void BoardGameFirstTest2() //Check value
        {
            BoardgameSingleton boardgame = BoardgameSingleton.GetInstance;
            BoardgameIterator boardgameIterator = boardgame.CreateIterator();
            ISquare square = boardgameIterator.First();
            Assert.AreEqual(square.GetSquareType(), "Starter Square");
        }



        [TestMethod]
        public void BoardGameNextTest()
        {
            BoardgameSingleton boardgame = BoardgameSingleton.GetInstance;
            BoardgameIterator boardgameIterator = boardgame.CreateIterator();
            for (int i = 1; i <= boardgame.Count; i++)
            {
                if (i <= boardgame.Count - 1) { Assert.IsTrue(boardgameIterator.Next() != null); }
                else if (i == boardgame.Count) { Assert.IsTrue(boardgameIterator.Next() == null); }
            }

        }


        [TestMethod]
        public void BoardGameIsCompletedTest()
        {
            BoardgameSingleton boardgame = BoardgameSingleton.GetInstance;
            BoardgameIterator boardgameIterator = boardgame.CreateIterator();
            for (int i = 1; i <= boardgame.Count + 1; i++)
            {

                if (i <= boardgame.Count) { Assert.IsTrue(boardgameIterator.IsCompleted != true); }
                else if (i > boardgame.Count) { Assert.IsTrue(boardgameIterator.IsCompleted == true); }
                boardgameIterator.Next();
            }

        }



    }

    #endregion

    #region Design Pattern Square 
    [TestClass]
    public class SquareTests
    {
        [TestMethod]
        public void SquareFactoryTest()
        {
            SquareFactory sf = new SquareFactory();
            Assert.IsTrue(sf.CreateSquare(SquareType.Normal) != null);
        }




        [TestMethod]
        public void CreateSquareTest2()
        {
            SquareFactory sf = new SquareFactory();
            List<ISquare> boardgame = new List<ISquare>();
            boardgame.Insert(0, sf.CreateSquare(SquareType.Start));
            Assert.AreEqual(boardgame[0].GetSquareType(), "Starter Square");


        }

        [TestMethod]
        public void GetTypesStartSquareTest()
        {
            SquareFactory sf = new SquareFactory();
            Assert.AreEqual(sf.CreateSquare(SquareType.Start).GetSquareType(), "Starter Square");

        }
        [TestMethod]
        public void GetTypesNormalSquareTest()
        {
            SquareFactory sf = new SquareFactory();
            Assert.AreEqual(sf.CreateSquare(SquareType.Normal).GetSquareType(), "Normal Square");
        }

        [TestMethod]
        public void GetTypesJailSquareTest()
        {
            SquareFactory sf = new SquareFactory();
            Assert.AreEqual(sf.CreateSquare(SquareType.Jail).GetSquareType(), "Jail Square");
        }


        [TestMethod]
        public void GetTypesGoToJailSquareTest()
        {
            SquareFactory sf = new SquareFactory();
            Assert.AreEqual(sf.CreateSquare(SquareType.GoToJail).GetSquareType(), "Go To Jail Square");
        }


    }
    #endregion

    #region Design Pattern Dices
    [TestClass]
    public class DicesTests
    {
        [TestMethod]
        public void DiceSingletonTest()
        {
            DicesSingleton dices = DicesSingleton.GetInstance;
            Assert.AreEqual(dices.GetType(), typeof(DicesSingleton));

        }

        [TestMethod]
        public void DiceSingletonTest2()
        {
            DicesSingleton dices = DicesSingleton.GetInstance;
            DicesSingleton dices2 = DicesSingleton.GetInstance;
            Assert.AreEqual(dices, dices2);

        }




        [TestMethod]
        public void SumDiceTest()
        {
            DicesSingleton dices = DicesSingleton.GetInstance;
            dices.D1 = 5;
            dices.D2 = 6;
            Assert.AreEqual(11, dices.SumDices());
        }

        [TestMethod]
        public void EqualityDiceTest()
        {
            DicesSingleton dices = DicesSingleton.GetInstance;
            dices.D1 = 5;
            dices.D2 = 6;
            Assert.IsFalse(dices.EqualityDices());
        }

        [TestMethod]
        public void ThrowDiceTest()
        {
            DicesSingleton dices = DicesSingleton.GetInstance;
            dices.ThrowDices();
            Assert.IsTrue(dices.D1 != 0 & dices.D2 != 0);
        }

    }



    #endregion

}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    /// Implements the IAggregatePlayer interface to return an instance of the IAggrefatePlayer
    /// This class permits to build an Iterator pattern for the players
    /// It is used to loop on players during the game and to display the statistics of the players at the end of the game
    /// </summary>
    public class PlayerList : IAggregatePlayer
    {
        /// <summary>
        /// The list of all players
        /// </summary>
        private readonly List<Player> listPlayers = new List<Player>();

        /// <summary>
        /// To create the iterator
        /// </summary>
        /// <returns>An instance of the class PlayerListIterator</returns>
        public PlayerListIterator CreateIterator()
        {
            return new PlayerListIterator(this);
        }

        /// <summary>
        /// To get the number of players in the list
        /// </summary>
        public int Count
        {
            get { return listPlayers.Count; }
        }

        /// <summary>
        /// To add a player to the list of players 
        /// </summary>
        /// <param name="player">An instance of the class Player</param>
        public void AddPlayer(Player player)
        {
            listPlayers.Add(player);
        }

        /// <summary>
        /// To get a player at a particular position in the list
        /// </summary>
        /// <param name="index">The position in the list</param>
        /// <returns>An instance of the Player class</returns>
        public Player GetPlayer(int index)
        {
            return listPlayers[index];
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    /// Iterator Design Pattern
    /// For the players
    /// Implements the the IPlayerAbstractIterator intrface as well as keeps track of the current position in the 
    /// traversal of the elements
    /// </summary>
    public class PlayerListIterator : IPlayerAbstractIterator
    {
        /// <summary>
        /// The collection of players
        /// </summary>
        readonly PlayerList collection;

        /// <summary>
        /// Current position in the traversal of the elements
        /// </summary>
        private int current = 0;

        /// <summary>
        /// Step to progress through the traversal of the elements
        /// </summary>
        readonly private int step = 1;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="collection">collection of players</param>
        public PlayerListIterator(PlayerList collection)
        {
            this.collection = collection;
        }

        /// <summary>
        /// The first element of the collection of players
        /// </summary>
        /// <returns>An instance of the player class</returns>
        public Player First()
        {
            current = 0;
            return collection.GetPlayer(current);
        }

        /// <summary>
        /// Any element, except the first, of the collection of players
        /// </summary>
        /// <returns>An instance of the player class</returns>
        public Player Next()
        {
            current += step;
            if (!IsCompleted)
            {
                return collection.GetPlayer(current);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// To know whether the iteration over the collection of players os over or not
        /// </summary>
        public bool IsCompleted
        {
            get { return current >= collection.Count; }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    /// Factory pattern
    /// To create different types of squares with common methods
    /// </summary>
    public interface ISquare
    {
        /// <summary>
        /// Get the particular type of the square (Jail, GoToJail, Normal or Start)
        /// </summary>
        /// <returns>The type as a string</returns>
        string GetSquareType();

        /// <summary>
        /// Visual representation of the square
        /// </summary>
        void Draw();
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    /// Factory pattern
    /// A type of square
    /// </summary>
    public class JailSquare : ISquare
    {
        /// <summary>
        /// Visual representation of the square
        /// </summary>
        public void Draw()
        {
            Console.WriteLine("- - - - - - - - - -\n" +
                this.GetSquareType() +
                "\n- - - - - - - - - -");
        }

        /// <summary>
        /// Get the particular type of the square (Jail)
        /// </summary>
        /// <returns>The type as a string</returns>
        public string GetSquareType()
        {
            return "Jail Square";
        }
    }
}

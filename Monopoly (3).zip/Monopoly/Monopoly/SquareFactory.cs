﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    /// This class permits to create a boardgame's square of the given type (normal, jail, start or go to jail)
    /// Is part of a factory pattern
    /// </summary>
    public class SquareFactory : AbstractSquareFactory
    {
        /// <summary>
        /// Returns the square of the wanted type
        /// </summary>
        /// <param name="type">Normal, jail, start, go to jail or unknown</param>
        /// <returns>A square from the interface ISquare</returns>
        public override ISquare CreateSquare(SquareType type)
        {
            switch (type)
            {
                case SquareType.Normal:
                    return new NormalSquare();
                case SquareType.Jail:
                    return new JailSquare();
                case SquareType.Start:
                    return new StartSquare();
                case SquareType.GoToJail:
                    return new GoToJailSquare();
                default:
                    throw new SquareTypeException("Cannot create such a square.");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    /// Iterator Design Pattern
    /// For the squares of the boardgame
    /// Creates an iterator object
    /// </summary>
    public interface IAggregateBoardgame
    {
        BoardgameIterator CreateIterator();
    }
}

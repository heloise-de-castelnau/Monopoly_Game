﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    /// Factory pattern
    /// A type of square
    /// </summary>
    class NormalSquare : ISquare
    {
        /// <summary>
        /// Visual representation of the square
        /// </summary>
        public void Draw()
        {
            Console.WriteLine("- - - - - - - - - -\n" +
                this.GetSquareType() +
                "\n- - - - - - - - - -");
        }

        /// <summary>
        /// Get the particular type of the square (Normal)
        /// </summary>
        /// <returns>The type as a string</returns>
        public string GetSquareType()
        {
            return "Normal Square";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    /// All possible types of square
    /// </summary>
    public enum SquareType { Normal, Jail, Start, GoToJail };

    /// <summary>
    /// Abstract class to create the square
    /// </summary>
    public abstract class AbstractSquareFactory
    {
        /// <summary>
        /// Abstract method to create the square
        /// </summary>
        public abstract ISquare CreateSquare(SquareType type);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    ///     Contains the global proceedings of the game
    /// </summary>
    class Program
    {
        /// <summary>
        ///     Constitution of the players' list
        /// </summary>
        /// <returns>
        ///     PlayerList instance
        /// </returns>
        public static PlayerList InitializationOfThePlayers()
        {
            Console.WriteLine("Hello! Welcome to your Monopoly Game! \nHow do you want to be called? >");
            string pseudo = Convert.ToString(Console.ReadLine());
            while (pseudo == "")
            {
                Console.WriteLine("How do you want to be called? >");
                pseudo = Convert.ToString(Console.ReadLine());
            }
            PlayerList playerList = new PlayerList();
            playerList.AddPlayer(new Player(pseudo));
            Console.WriteLine("A player has been added to the game: " + pseudo + "\n");
            Console.WriteLine("Is there anyone who would you like to join as another player? (y/n) >");
            string temp = Convert.ToString(Console.ReadLine());
            while (temp == "")
            {
                Console.WriteLine("Is there anyone who would you like to join as another player? (y/n) >");
                temp = Convert.ToString(Console.ReadLine());
            }
            char answer = temp.ToLower()[0];
            while (!"yn".Contains(answer))
            {
                Console.WriteLine("Sorry but we do not understand your answer. Is there anyone who would like to join as another player? (y/n) >");
                temp = Convert.ToString(Console.ReadLine());
                while (temp == "")
                {
                    Console.WriteLine("Is there anyone who would you like to join as another player? (y/n) >");
                    temp = Convert.ToString(Console.ReadLine());
                }
                answer = temp.ToLower()[0];
            }
            Console.WriteLine("");
            while (answer == 'y')
            {
                Console.WriteLine("Welcome to you, new player! \nHow do you want to be called? >");
                pseudo = Convert.ToString(Console.ReadLine());
                while (pseudo == "")
                {
                    Console.WriteLine("How do you want to be called? >");
                    pseudo = Convert.ToString(Console.ReadLine());
                }
                playerList.AddPlayer(new Player(pseudo));
                Console.WriteLine("A player has been added to the game: " + pseudo + "\n");
                Console.WriteLine("Is there anyone who would you like to join as another player? (y/n) >");
                temp = Convert.ToString(Console.ReadLine());
                while (temp == "")
                {
                    Console.WriteLine("Is there anyone who would you like to join as another player? (y/n) >");
                    temp = Convert.ToString(Console.ReadLine());
                }
                answer = temp.ToLower()[0];
                while (!"yn".Contains(answer))
                {
                    Console.WriteLine("Sorry but we do not understand your answer. Is there anyone who would like to " +
                        "join as another player? (y/n) >");
                    temp = Convert.ToString(Console.ReadLine());
                    while (temp == "")
                    {
                        Console.WriteLine("Is there anyone who would you like to join as another player? (y/n) >");
                        temp = Convert.ToString(Console.ReadLine());
                    }
                    answer = temp.ToLower()[0];
                }
            }
            return playerList;
        }

        /// <summary>
        ///     General proceedings of the game: Initialization of the players, initialization of the boardgame, 
        ///     successive turns of each player, resume of each player at the end of the game.
        /// </summary>
        public static void Game()
        {
            PlayerList playerList = InitializationOfThePlayers();
            Console.WriteLine("Okay, let's begin the game!\nHere is a general view of the boardgame:");
            BoardgameSingleton boardgame = BoardgameSingleton.GetInstance;
            BoardgameIterator boardgameIterator = boardgame.CreateIterator();
            for(ISquare square = boardgameIterator.First(); !boardgameIterator.IsCompleted; square = boardgameIterator.Next())
            {
                square.GetSquareType();
                square.Draw();
            }
            Console.WriteLine("Let's begin the first turn. \n");
            int counter = 0;
            string temp;
            char answer = 'y';
            PlayerListIterator iterator = playerList.CreateIterator();

            while (answer == 'y')
            {
                if (counter % 4 == 3)
                {
                    Console.WriteLine("Would you like to continue the game? (y/n) >");
                    temp = Convert.ToString(Console.ReadLine());
                    while (temp == "")
                    {
                        Console.WriteLine("Would you like to continue the game? (y/n) >");
                        temp = Convert.ToString(Console.ReadLine());
                    }
                    answer = temp.ToLower()[0];
                    while (!"yn".Contains(answer))
                    {
                        Console.WriteLine("Sorry but we do not understand your answer. Would you like to continue the game? (y/n) >");
                        temp = Convert.ToString(Console.ReadLine());
                        while (temp == "")
                        {
                            Console.WriteLine("Would you like to continue the game? (y/n) >");
                            temp = Convert.ToString(Console.ReadLine());
                        }
                        answer = temp.ToLower()[0];
                    }
                    if (answer == 'n')
                        break;
                }
                for (Player player = iterator.First(); !iterator.IsCompleted; player = iterator.Next())
                {
                    player.PlayerTurn();
                }
                counter++;
            }
            Console.WriteLine("The game is now over. Here are the statistics of each player: ");
            for (Player player = iterator.First(); !iterator.IsCompleted; player = iterator.Next())
            {
                player.Resume();
            }
        }

        /// <summary>
        /// Main
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Game();
            Console.ReadLine();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    /// This class takes the responsibility of the initialization of a player and the management of his turn when it's time for
    /// this player to play the game.
    /// </summary>
    public class Player
    {
        /// <summary>
        /// The pseudo chosen by the player
        /// </summary>
        public string Pseudo { get; set; }

        /// <summary>
        /// The current square the player is at
        /// </summary>
        public int Squares { get; set; }

        /// <summary>
        /// The length of the path he travelled since the beginning
        /// </summary>
        public int StaysInJail { get; set; }

        /// <summary>
        /// The number of complete paths around the boardgame
        /// </summary>
        public int Starts { get; set; }

        /// <summary>
        /// The current number of stays in jail the player made (between 0 and 39)
        /// </summary>
        public int CurrentSquare { get; set; }

        /// <summary>
        /// A boolean that describes whether the player is in jail or not
        /// </summary>
        public bool Jail { get; set; }

        /// <summary>
        /// If the player is currently in jail, shows the number of turns he spent in jail
        /// </summary>
        public int TimeInJail { get; set; }

        /// <summary>
        /// Constructor to initialize a new player
        /// </summary>
        /// <param name="pseudo">The only parameter needed</param>
        public Player(string pseudo)
        {
            Pseudo = pseudo;
            Squares = 0;
            StaysInJail = 0;
            Starts = 0;
            CurrentSquare = 0;
            Jail = false;
            TimeInJail = 0;
        }

        /// <summary>
        /// A method to simulate the player moving on the boardgame
        /// </summary>
        public void MoveOn()
        {
            DicesSingleton dices = DicesSingleton.GetInstance;
            CurrentSquare += dices.SumDices();
            Squares += dices.SumDices();
            if (CurrentSquare >= 40)
                Starts++;
            CurrentSquare %= 40;
            BoardgameSingleton boardgame = BoardgameSingleton.GetInstance;
            ISquare square = boardgame.GetSquare(CurrentSquare);
            Console.WriteLine("You're currently at position " + (CurrentSquare + 1) + "/40 on the board, on a " + square.GetSquareType()+".");
            if (CurrentSquare == 30)
            {
                CurrentSquare = 10;
                Jail = true;
                TimeInJail = 0;
                StaysInJail++;
                Console.WriteLine("Unfortunately, you landed on the Go To Jail square so you're moving in jail...");
            }
        }

        /// <summary>
        /// The method that simulate the entire turn of one player
        /// </summary>
        public void PlayerTurn()
        {
            Console.WriteLine(Pseudo + ", it is now your turn to play!");
            DicesSingleton dices = DicesSingleton.GetInstance;
            // Test whether the player is in jail
            if (Jail)
            {
                //if yes, test whether the player already spent 3 turns in jail
                if (TimeInJail == 3)
                {
                    Console.WriteLine("Congratulations! You're now out of jail!\n" +
                        "Throw the dices to move on !");
                    Console.WriteLine("To throw the dices, just press the enter button.");
                    Console.ReadLine();
                    dices.ThrowDices();
                    dices.DrawDices();
                    Jail = false;
                    TimeInJail = 0;
                    MoveOn();
                    
                }
                else
                {
                    Console.WriteLine("Unfortunately you are still in jail... Try to throw the dices to move out of jail!");
                    Console.WriteLine("To throw the dices, just press the enter button.");
                    Console.ReadLine();
                    dices.ThrowDices();
                    dices.DrawDices();
                    if (dices.EqualityDices())
                    {
                        Console.WriteLine("Congratulations! You're out of jail!");
                        Jail = false;
                        TimeInJail = 0;
                        MoveOn();
                    }
                    else
                    {
                        TimeInJail++;
                        if (TimeInJail == 3)
                            Console.WriteLine("It is not for now... But next time you'll be able to move on!");
                        else
                            Console.WriteLine("It is not for now... Better luck next time! ");
                    }
                }
            }
            else
            {
                int counter = 0;
                while (counter < 3)
                {
                    if (counter > 0)
                        Console.WriteLine("Congratulations! You did a double! You can play again.\n");
                    counter++;
                    Console.WriteLine("To throw the dices, just press the enter button.");
                    Console.ReadLine();
                    dices.ThrowDices();
                    dices.DrawDices();
                    MoveOn();
                    if (!dices.EqualityDices() || Jail==true)
                        break;
                    if (counter == 3)
                    {
                        CurrentSquare = 10;
                        Jail = true;
                        TimeInJail = 0;
                        StaysInJail++;
                        Console.WriteLine("Unfortunately, you did 3 doubles in a row so you're moving in jail... Your turn ends there.");
                        break;
                    }
                }
            }
            Console.WriteLine("You're now done. Next!\n" +
                "____________________________________");
        }

        /// <summary>
        /// A method to display the statistics of a player at the end of the game
        /// </summary>
        public void Resume()
        {
            Console.WriteLine("Statistics of the player " + this.Pseudo + ":\n" +
                "Total length of the journey: " + this.Squares + "\n" +
                "Number of stays in jail: " + this.StaysInJail + "\n" +
                "Number of complete paths around the boardgame: " + this.Starts + "\n" +
                "Current square: " + this.CurrentSquare + "\n" +
                "- - - - - - - - - - - - - - - - - - - -");
        }
    }
}

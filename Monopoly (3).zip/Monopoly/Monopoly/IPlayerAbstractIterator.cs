﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    /// Iterator Design Pattern
    /// For the players
    /// The interface designs an interface for accessing and traversaling elements
    /// </summary>
    public interface IPlayerAbstractIterator
    {
        /// <summary>
        /// The first element of the collection of players
        /// </summary>
        /// <returns>An instance of the player class</returns>
        Player First();

        /// <summary>
        /// Any element, except the first, of the collection of players
        /// </summary>
        /// <returns>An instance of the player class</returns>
        Player Next();

        /// <summary>
        /// To know whether the iteration over the collection of players is over or not
        /// </summary>
        bool IsCompleted { get; }
    }
}

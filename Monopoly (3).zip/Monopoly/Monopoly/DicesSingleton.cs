﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    /// Singleton pattern
    /// This class permits to create and use a set of two dices
    /// </summary>
    public sealed class DicesSingleton
    {
        /// <summary>
        /// First dice
        /// </summary>
        public int D1 { get; set; }

        /// <summary>
        /// Second dice
        /// </summary>
        public int D2 { get; set; }

        /// <summary>
        /// To simulate the throw of dices
        /// </summary>
        private Random random = new Random();

        /// <summary>
        /// The only instance of the class
        /// </summary>
        private static DicesSingleton instance = null;

        /// <summary>
        /// Constructor
        /// Will be called only once during the execution
        /// </summary>
        private DicesSingleton()
        {
            D1 = 0;
            D2 = 0;
        }

        /// <summary>
        /// Is used as a constructor and permits to create only one instance during the execution
        /// </summary>
        public static DicesSingleton GetInstance
        {
            get
            {
                if (instance == null)
                    instance = new DicesSingleton();
                return instance;
            }
        }

        /// <summary>
        /// Sum of both dices
        /// </summary>
        /// <returns>The sum</returns>
        public int SumDices()
        {
            return D1 + D2;
        }

        /// <summary>
        /// Tests the equality
        /// </summary>
        /// <returns>A boolean that describes whether the dices are equal or not</returns>
        public bool EqualityDices()
        {
            return D1 == D2;
        }

        /// <summary>
        /// Simulates a throw of 2 dices
        /// </summary>
        public void ThrowDices()
        {
            D1 = random.Next(1, 7);
            D2 = random.Next(1, 7);
        }

        /// <summary>
        /// Permits a visualisation of the dices, is used after each throw
        /// </summary>
        public void DrawDices()
        {
            switch (D1)
            {
                case 1:
                    Console.WriteLine(
                        "---------\n" +
                        "|       |\n" +
                        "|   *   |\n" +
                        "|       |\n" +
                        "---------\n");
                    break;
                case 2:
                    Console.WriteLine(
                        "---------\n" +
                        "|*      |\n" +
                        "|       |\n" +
                        "|      *|\n" +
                        "---------\n");
                    break;
                case 3:
                    Console.WriteLine(
                        "---------\n" +
                        "|*      |\n" +
                        "|   *   |\n" +
                        "|      *|\n" +
                        "---------\n");
                    break;
                case 4:
                    Console.WriteLine(
                        "---------\n" +
                        "|*     *|\n" +
                        "|       |\n" +
                        "|*     *|\n" +
                        "---------\n");
                    break;
                case 5:
                    Console.WriteLine(
                        "---------\n" +
                        "|*     *|\n" +
                        "|   *   |\n" +
                        "|*     *|\n" +
                        "---------\n");
                    break;
                case 6:
                    Console.WriteLine(
                        "---------\n" +
                        "|*     *|\n" +
                        "|*     *|\n" +
                        "|*     *|\n" +
                        "---------\n");
                    break;
                default:
                    Console.WriteLine(
                        "---------\n" +
                        "|       |\n" +
                        "|       |\n" +
                        "|       |\n" +
                        "---------\n");
                    break;
            }

            switch (D2)
            {
                case 1:
                    Console.WriteLine(
                        "---------\n" +
                        "|       |\n" +
                        "|   *   |\n" +
                        "|       |\n" +
                        "---------\n");
                    break;
                case 2:
                    Console.WriteLine(
                        "---------\n" +
                        "|*      |\n" +
                        "|       |\n" +
                        "|      *|\n" +
                        "---------\n");
                    break;
                case 3:
                    Console.WriteLine(
                        "---------\n" +
                        "|*      |\n" +
                        "|   *   |\n" +
                        "|      *|\n" +
                        "---------\n");
                    break;
                case 4:
                    Console.WriteLine(
                        "---------\n" +
                        "|*     *|\n" +
                        "|       |\n" +
                        "|*     *|\n" +
                        "---------\n");
                    break;
                case 5:
                    Console.WriteLine(
                        "---------\n" +
                        "|*     *|\n" +
                        "|   *   |\n" +
                        "|*     *|\n" +
                        "---------\n");
                    break;
                case 6:
                    Console.WriteLine(
                        "---------\n" +
                        "|*     *|\n" +
                        "|*     *|\n" +
                        "|*     *|\n" +
                        "---------\n");
                    break;
                default:
                    Console.WriteLine(
                        "---------\n" +
                        "|       |\n" +
                        "|       |\n" +
                        "|       |\n" +
                        "---------\n");
                    break;
            }
        }
    }
}

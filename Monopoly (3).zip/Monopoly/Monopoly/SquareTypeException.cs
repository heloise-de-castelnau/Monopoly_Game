﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    /// Factory pattern
    /// The management if it is required to create an impossible square
    /// </summary>
    public class SquareTypeException : Exception
    {
        /// <summary>
        /// The message to be displayed
        /// </summary>
        private string message;

        /// <summary>
        /// Raise the error and displays the error message
        /// </summary>
        /// <param name="message">The message</param>
        public SquareTypeException(string message)
        {
            this.message = message;
        }
    }
}

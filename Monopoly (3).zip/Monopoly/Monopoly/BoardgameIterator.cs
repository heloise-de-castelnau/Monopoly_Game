﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    /// /// <summary>
    /// Iterator Design Pattern
    /// For the squares of the boardgame
    /// Implements the the IBoardgameAbstractIterator intrface as well as keeps track of the current position in 
    /// the traversal of the elements
    /// </summary>
    /// </summary>
    public class BoardgameIterator : IBoardgameAbstractIterator
    {
        /// <summary>
        /// The boardgame, a collection of squares
        /// </summary>
        readonly BoardgameSingleton collection;

        /// <summary>
        /// Current position in the proceedings of the traversal
        /// </summary>
        private int current = 0;

        /// <summary>
        /// Step to progress through the traversal of the elements
        /// </summary>
        readonly private int step = 1;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="collection">The boardgame, a collection of squares</param>
        public BoardgameIterator(BoardgameSingleton collection)
        {
            this.collection = collection;
        }

        /// <summary>
        /// To know whether the iteration over the boardgame is over or not
        /// </summary>
        public bool IsCompleted
        {
            get { return current >= collection.Count; }
        }

        /// <summary>
        /// The first element of the boardgame which is a collection of squares
        /// </summary>
        /// <returns>An instance of the ISquare interface</returns>
        public ISquare First()
        {
            current = 0;
            return collection.GetSquare(current);
        }

        /// <summary>
        /// Any element, except the first, of the boardgame which is a collection of squares
        /// </summary>
        /// <returns>An instance of the ISquare interface</returns>
        public ISquare Next()
        {
            current += step;
            if (!IsCompleted)
            {
                return collection.GetSquare(current);
            }
            else
            {
                return null;
            }
        }
    }
}

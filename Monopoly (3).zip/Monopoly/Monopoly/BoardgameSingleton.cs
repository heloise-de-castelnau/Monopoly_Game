﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    /// Iterator pattern
    /// Singleton pattern
    /// This class permits to create and use a single boardgame
    /// Is built using a singleton pattern & is a part of an iterator pattern
    /// </summary>
    public sealed class BoardgameSingleton : IAggregateBoardgame
    {
        /// <summary>
        /// The only instance of the class
        /// </summary>
        private static BoardgameSingleton instance = null;

        /// <summary>
        /// The boardgame composed of different squares
        /// </summary>
        public List<ISquare> boardgame = new List<ISquare>();

        /// <summary>
        /// Constructor - Where the boardgame is constructed with squares
        /// Will be called only once during the execution
        /// </summary>
        private BoardgameSingleton()
        {
            SquareFactory sf = new SquareFactory();
            for(int i = 0; i < 37; i++)
            {
                boardgame.Add(sf.CreateSquare(SquareType.Normal));
            }
            boardgame.Insert(0, sf.CreateSquare(SquareType.Start));
            boardgame.Insert(10, sf.CreateSquare(SquareType.Jail));
            boardgame.Insert(30, sf.CreateSquare(SquareType.GoToJail));
        }

        /// <summary>
        /// Is used as a constructor and permits to create only one instance during the execution
        /// </summary>
        public static BoardgameSingleton GetInstance
        {
            get
            {
                if (instance == null)
                    instance = new BoardgameSingleton();
                return instance;
            }
        }

        /// <summary>
        /// To obtain the number of squares on the boardgame
        /// </summary>
        public int Count
        {
            get { return boardgame.Count; }
        }

        /*
        /// <summary>
        /// To add a new square to the boardgame
        /// </summary>
        /// <param name="square">An instance of the wanted type of square</param>
        public void AddSquare(ISquare square)
        {
            boardgame.Add(square);
        }
        */

        /// <summary>
        /// To get the instance of the square at a particular position on the boardgame
        /// </summary>
        /// <param name="index">The index of the position, between 0 and 39</param>
        /// <returns>Returns the square</returns>
        public ISquare GetSquare(int index)
        {
            return boardgame[index];
        }

        /// <summary>
        /// Permits to iterate on the boardgame and display it at the beginning of the game
        /// </summary>
        /// <returns></returns>
        public BoardgameIterator CreateIterator()
        {
            return new BoardgameIterator(this);
        }
    }
}
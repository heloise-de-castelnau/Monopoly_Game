﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly
{
    /// <summary>
    /// Iterator Design Pattern
    /// For the boardgame
    /// The interface designs an interface for accessing and traversaling elements
    /// </summary>
    public interface IBoardgameAbstractIterator
    {
        /// <summary>
        /// The first element of the boardgame which is a collection of squares
        /// </summary>
        /// <returns>An instance of the ISquare interface</returns>
        ISquare First();

        /// <summary>
        /// Any element, except the first, of the boardgame which is a collection of squares
        /// </summary>
        /// <returns>An instance of the ISquare interface</returns>
        ISquare Next();

        /// <summary>
        /// To know whether the iteration over the boardgame is over or not
        /// </summary>
        bool IsCompleted { get; }
    }
}
